import java.util.List;

/**
 * Escreva uma descrição da classe Diario aqui.
 * 
 * @author (seu nome) 
 * @version (um número da versão ou uma data)
 */
public class Diario
{
    //ATRIBUTOS:
    private List<Registro> registros;
    
    
    //construtor
    
    //addRegistro...
    
    public void listRegistros(){
        //for i...  for igual do C
            Registro item = registros.get(i);
            System.out.println(item.getData()+"\t"+item.getDuracao+"\t"+...)
    }
    
    public void listRegistros2(){
        
    }
    
    public void listRegistros3(){
        
    }
}
