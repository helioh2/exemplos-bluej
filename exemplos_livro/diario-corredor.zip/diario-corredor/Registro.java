
/**
 * Escreva uma descrição da classe Registro aqui.
 * 
 * @author (seu nome) 
 * @version (um número da versão ou uma data)
 */
public class Registro
{
    private String data;
    //...
    
    
    // getters 
    //getData
    //getDuracao
    //getDistancia
    //getComentario
}
